import tkinter as tk
from PIL import Image, ImageTk
import time
import winsound
import os
import wave

# Create the main window
root = tk.Tk()
root.title("My Application")

# Set window position and size (width x height + x position + y position)
SCREEN_WIDTH = 400
PLAYER_HITBOX_SIZE = 50
window_x = 0 # X coordinate on screen
window_y = 450  # Y coordinate on screen
root.geometry(f"{SCREEN_WIDTH}x340+{window_x}+{window_y}")
root.resizable(False, False)

# Create a canvas for the ground
canvas = tk.Canvas(root, bg="white", highlightthickness=0)
canvas.pack(fill=tk.BOTH, expand=True)

# Draw a black rectangle as the ground
canvas.create_rectangle(0, 280, 400, 340, fill="black", outline="black")

# Orb class to manage position and size
class Orb:
    def __init__(self, canvas, x, y, size):
        self.canvas = canvas
        self.x = x
        self.y = y
        self.size = size
        self.image_id = None
        self.photo = None  # Store photo reference
        self.original_image = Image.open("orb.png")
        self.current_idle_image = "orb.png"  # Track which idle image to use
        self.is_walking = False
        self.animation_frames = None
        self.animation_frames_left = None  # For left walking animation
        self.current_frame = 0
        self._walking = False  # For continuous walking
        self._walking_left = False  # For left walking
        self.frame_counter = 0
        self.animation_id = None  # Track animation callback ID
        self.a_disabled = False  # True means orb2.png, False means orb.png
        self.draw()
    
    def set_position(self, x, y):
        """Update the orb position"""
        self.x = x
        self.y = y
        self.draw()
    
    def set_size(self, size):
        """Update the orb size"""
        self.size = size
        self.draw()
    
    def load_animation(self, gif_path):
        """Load animation frames from a GIF"""
        gif = Image.open(gif_path)
        self.animation_frames = []
        try:
            while True:
                frame = gif.copy().convert("RGBA")
                self.animation_frames.append(frame)
                gif.seek(len(self.animation_frames))
        except EOFError:
            pass
        return len(self.animation_frames) if self.animation_frames else 0
    
    def load_animation_left(self, gif_path):
        """Load left animation frames from a GIF"""
        gif = Image.open(gif_path)
        self.animation_frames_left = []
        try:
            while True:
                frame = gif.copy().convert("RGBA")
                self.animation_frames_left.append(frame)
                gif.seek(len(self.animation_frames_left))
        except EOFError:
            pass
        return len(self.animation_frames_left) if self.animation_frames_left else 0
    
    def walk_right(self, distance=100, speed=5):
        """Make the orb walk right with animation"""
        if self.is_walking or not self.animation_frames:
            return
        
        self.is_walking = True
        start_x = self.x
        end_x = start_x + distance
        steps = distance // speed
        
        def animate_walk(step):
            if step <= steps:
                # Update position
                self.x = start_x + (step * speed)
                # Update animation frame
                frame_index = (step // 2) % len(self.animation_frames)
                frame = self.animation_frames[frame_index].resize((self.size, self.size), Image.Resampling.LANCZOS)
                self.photo = ImageTk.PhotoImage(frame)
                
                if not hasattr(self.canvas, 'images'):
                    self.canvas.images = []
                self.canvas.images.append(self.photo)
                
                if self.image_id:
                    self.canvas.delete(self.image_id)
                self.image_id = self.canvas.create_image(self.x, self.y, image=self.photo)
                
                self.canvas.after(50, animate_walk, step + 1)
            else:
                self.is_walking = False
                self.draw()  # Return to idle state with original image
        
        animate_walk(0)
    
    def start_walking(self):
        """Start continuous walking right"""
        if not self.animation_frames or self._walking:
            return
        
        # Cancel any existing animation
        if self.animation_id:
            self.canvas.after_cancel(self.animation_id)
        
        self._walking = True
        self._walking_left = False
        self.frame_counter = 0
        
        def continuous_walk():
            if self._walking:
                # Move right
                self.x += 5
                # Update animation frame
                frame_index = (self.frame_counter // 2) % len(self.animation_frames)
                frame = self.animation_frames[frame_index].resize((self.size, self.size), Image.Resampling.LANCZOS)
                self.photo = ImageTk.PhotoImage(frame)
                
                if not hasattr(self.canvas, 'images'):
                    self.canvas.images = []
                self.canvas.images.append(self.photo)
                
                if self.image_id:
                    self.canvas.delete(self.image_id)
                self.image_id = self.canvas.create_image(self.x, self.y, image=self.photo)

                # Check the invisible right-side hitbox.
                check_window_hitbox()
                
                self.frame_counter += 1
                self.animation_id = self.canvas.after(50, continuous_walk)
        
        continuous_walk()
    
    def stop_walking(self):
        """Stop walking and return to appropriate idle state based on a_disabled"""
        self._walking = False
        
        # Cancel any pending animation callback
        if self.animation_id:
            self.canvas.after_cancel(self.animation_id)
            self.animation_id = None
        
        # Show the appropriate idle image based on a_disabled state
        if self.a_disabled:
            self.current_idle_image = "orb2.png"
        else:
            self.current_idle_image = "orb.png"
        
        self.original_image = Image.open(self.current_idle_image)
        self.draw()
    
    def start_walking_left(self):
        """Start continuous walking left"""
        if self._walking_left:
            return

        if not self.animation_frames_left:
            return

        if self.animation_id:
            self.canvas.after_cancel(self.animation_id)
            self.animation_id = None

        self._walking_left = True
        self._walking = False
        self.frame_counter = 0

        self._animate_walk_left()

    def _animate_walk_left(self):
        """Continuously loop orbwalk2.gif while A is held"""
        if not self._walking_left or not self.animation_frames_left:
            return

        self.x -= 5

        frame_index = (self.frame_counter // 2) % len(self.animation_frames_left)
        frame = self.animation_frames_left[frame_index].resize(
            (self.size, self.size),
            Image.Resampling.LANCZOS
        )
        self.photo = ImageTk.PhotoImage(frame)

        if not hasattr(self.canvas, 'images'):
            self.canvas.images = []
        self.canvas.images.append(self.photo)

        if self.image_id:
            self.canvas.delete(self.image_id)

        self.image_id = self.canvas.create_image(
            self.x, self.y, image=self.photo
        )

        # Check the invisible left-side hitbox.
        check_window_hitbox()

        self.frame_counter += 1
        self.animation_id = self.canvas.after(50, self._animate_walk_left)
    
    def stop_walking_left(self):
        """Stop walking left and show orb2.png"""
        self._walking_left = False
        
        # Cancel any pending animation callback
        if self.animation_id:
            self.canvas.after_cancel(self.animation_id)
            self.animation_id = None
        
        # Return to orb2.png
        self.current_idle_image = "orb2.png"
        self.original_image = Image.open("orb2.png")
        self.draw()
    
    def draw(self):
        """Redraw the orb with current position and size"""
        # Resize the image
        resized_image = self.original_image.resize((self.size, self.size), Image.Resampling.LANCZOS)
        self.photo = ImageTk.PhotoImage(resized_image)
        
        # Store reference on canvas to prevent garbage collection
        if not hasattr(self.canvas, 'images'):
            self.canvas.images = []
        self.canvas.images.append(self.photo)
        
        # Remove old image if it exists
        if self.image_id:
            self.canvas.delete(self.image_id)
        
        # Draw new image
        self.image_id = self.canvas.create_image(self.x, self.y, image=self.photo)

# Create the orb
orb = Orb(canvas, 50, 255, 50)

# Load the walking animations
orb.load_animation("orbwalk.gif")
orb.load_animation_left("orbwalk2.gif")

# Invisible player hitbox and invisible window-side hitboxes
# The player hitbox follows the orb automatically because it uses orb.x/orb.y.
PLAYER_HALF = PLAYER_HITBOX_SIZE / 2
LEFT_HITBOX = (0, 0, 5, 340)
RIGHT_HITBOX = (SCREEN_WIDTH - 5, 0, SCREEN_WIDTH, 340)

# Real Canvas hitboxes, hidden so they are completely invisible.
left_hitbox_id = canvas.create_rectangle(*LEFT_HITBOX, state=tk.HIDDEN)
right_hitbox_id = canvas.create_rectangle(*RIGHT_HITBOX, state=tk.HIDDEN)

window_wrap_cooldown = False

def clear_window_wrap_cooldown():
    global window_wrap_cooldown
    window_wrap_cooldown = False

def check_window_hitbox():
    """Move the window and wrap the orb to the opposite side."""
    global window_x, window_wrap_cooldown

    if window_wrap_cooldown:
        return

    player_left = orb.x - PLAYER_HALF
    player_right = orb.x + PLAYER_HALF

    # RIGHT SIDE: move the whole game window one window-width to the right.
    # This works no matter where the game window currently is.
    if player_right >= SCREEN_WIDTH:
        window_x += SCREEN_WIDTH
        root.geometry(f"{SCREEN_WIDTH}x340+{window_x}+{window_y}")
        orb.x = PLAYER_HALF
        orb.draw()
        window_wrap_cooldown = True
        root.after(100, clear_window_wrap_cooldown)

    # LEFT SIDE: move the whole game window one window-width to the left.
    elif player_left <= 0:
        window_x -= SCREEN_WIDTH
        root.geometry(f"{SCREEN_WIDTH}x340+{window_x}+{window_y}")
        orb.x = SCREEN_WIDTH - PLAYER_HALF
        orb.draw()
        window_wrap_cooldown = True
        root.after(100, clear_window_wrap_cooldown)

# Footstep sound
steps_sound = os.path.join(os.path.dirname(os.path.abspath(__file__)), "steps.wav")
walking_keys = set()
footstep_job = None

def get_sound_length_ms():
    """Get the WAV duration so we can loop it reliably."""
    try:
        with wave.open(steps_sound, "rb") as wav:
            frames = wav.getnframes()
            rate = wav.getframerate()
            if rate:
                return max(50, int((frames / rate) * 1000))
    except Exception as e:
        print("Could not read steps.wav:", e)
    return 500

def play_footstep():
    global footstep_job

    if not walking_keys:
        footstep_job = None
        return

    if not os.path.exists(steps_sound):
        print("steps.wav was not found here:", steps_sound)
        footstep_job = None
        return

    try:
        # Play one copy, then schedule the next one after it finishes.
        winsound.PlaySound(
            steps_sound,
            winsound.SND_FILENAME | winsound.SND_ASYNC
        )
    except Exception as e:
        print("Could not play steps.wav:", e)
        footstep_job = None
        return

    footstep_job = root.after(get_sound_length_ms(), play_footstep)

def start_footsteps():
    global footstep_job
    if not walking_keys:
        return
    if footstep_job is None:
        play_footstep()

def stop_footsteps():
    global footstep_job
    if not walking_keys:
        if footstep_job is not None:
            root.after_cancel(footstep_job)
            footstep_job = None
        winsound.PlaySound(None, 0)

# Bind keyboard events
def on_key_down(event):
    key = event.keysym.lower()

    if key == 'd':
        orb.start_walking()
        if 'd' not in walking_keys:
            walking_keys.add('d')
            start_footsteps()

    elif key == 'a':
        orb.start_walking_left()
        if 'a' not in walking_keys:
            walking_keys.add('a')
            start_footsteps()

def on_key_up(event):
    key = event.keysym.lower()

    if key == 'd':
        orb.stop_walking()
        walking_keys.discard('d')
        stop_footsteps()

    elif key == 'a':
        orb.stop_walking_left()
        walking_keys.discard('a')
        stop_footsteps()

root.bind('<KeyPress-d>', on_key_down)
root.bind('<KeyPress-D>', on_key_down)
root.bind('<KeyRelease-d>', on_key_up)
root.bind('<KeyRelease-D>', on_key_up)
root.bind('<KeyPress-a>', on_key_down)
root.bind('<KeyPress-A>', on_key_down)
root.bind('<KeyRelease-a>', on_key_up)
root.bind('<KeyRelease-A>', on_key_up)

# Run the application
root.mainloop()
